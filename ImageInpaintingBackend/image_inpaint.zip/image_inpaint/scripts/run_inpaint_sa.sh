python3 train_sagan.py config/inpaint_places2.yml
