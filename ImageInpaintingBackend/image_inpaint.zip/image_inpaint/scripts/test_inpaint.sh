python test_images.py config/test_places2_sagan.yml
